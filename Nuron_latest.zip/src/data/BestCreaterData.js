import {
    Client_1
} from "../utils/allImgs";

export const bestCreater = [
    {
        title: 'Brodband',
        number: '$2500,000',
        img: Client_1,

    },
    {
        title: 'Marks',
        number: '    $2200,000',
        img: Client_1,

    },
    {
        title: 'JOne Lee',
        number: '$900,000',
        img: Client_1,

    },
    {
        title: 'Malinga',
        number: '$2400,000',
        img: Client_1,

    },
    {
        title: 'Favis',
        number: '$290,000',
        img: Client_1,

    },
    {
        title: 'Fakir',
        number: '$299,00,000',
        img: Client_1,

    },
    {
        title: 'Sajib',
        number: '$1100,000',
        img: Client_1,

    },
    {
        title: 'Mikel',
        number: '$2500,000',
        img: Client_1,

    },
]