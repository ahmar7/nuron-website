import {
    Blog_1
} from "../utils/allImgs";

export const createrData = [
    {
        name: 'Allen Waltker',
        bid: '0.11wETH by',
        time: ' 1 hours ago',

    },
    {
        name: 'Joe Biden',
        bid: '0.09wETH by',
        time: '1.30 hours ago',

    },
    {
        name: 'Sonial mridha',
        bid: '0.07wETH by ',
        time: '1.35 hours ago',

    },
    {
        name: 'Tribute Dhusra',
        bid: '0.07wETH by ',
        time: '1.55 hours ago',

    },
    {
        name: 'Sonia Sobnom',
        bid: '0.05wETH by ',
        time: '1.9 hours ago',

    },
    {
        name: 'Tribute Dhusra',
        bid: '0.07wETH by ',
        time: '1.55 hours ago',

    },
]

export const propertyData = [
    {
        type: 'HYPE TYPE',
        value: 'CALM AF (STILL)',
    },
    {
        type: 'BASTARDNESS',
        value: 'C00LIO BASTARD',
    },
    {
        type: 'TYPE',
        value: 'APE',
    },
    {
        type: 'ASTARDNESS',
        value: 'BASTARD',
    },
    {
        type: 'BAD HABIT(S)',
        value: 'PIPE',
    },
    {
        type: 'BID',
        value: 'BPEYti',
    },
    {
        type: 'ASTRAGENAKAR',
        value: 'BASTARD',
    },
    {
        type: 'CITY',
        value: 'TOKYO',
    },

]



