import {
    Client_2
} from "../utils/allImgs";

export const creatersData = [
    {
        name: 'Allen Waltker',
        amount: '$2200,000',
        img: Client_2,

    },
    {
        name: 'JOne Lee',
        amount: '$900,000',
        img: Client_2,

    },
    {
        name: 'Malinga',
        amount: '$2400,000',
        img: Client_2,

    },
    {
        name: 'Torpedo',
        amount: '$8500,000',
        img: Client_2,

    },
    {
        name: 'Malinga',
        amount: '$2400,000',
        img: Client_2,

    },
    {
        name: 'Torpedo',
        amount: '$8500,000',
        img: Client_2,

    },
    {
        name: 'Allen Waltker',
        amount: '$2200,000',
        img: Client_2,

    },
    {
        name: 'JOne Lee',
        amount: '$900,000',
        img: Client_2,

    },
    {
        name: 'Malinga',
        amount: '$2400,000',
        img: Client_2,

    },
    {
        name: 'Torpedo',
        amount: '$8500,000',
        img: Client_2,

    },
    {
        name: 'Malinga',
        amount: '$2400,000',
        img: Client_2,

    },
    {
        name: 'Malinga',
        amount: '$2400,000',
        img: Client_2,

    },
    {
        name: 'JOne Lee',
        amount: '$900,000',
        img: Client_2,

    },
    {
        name: 'Malinga',
        amount: '$2400,000',
        img: Client_2,

    },
    {
        name: 'Torpedo',
        amount: '$8500,000',
        img: Client_2,

    },
    {
        name: 'Malinga',
        amount: '$2400,000',
        img: Client_2,

    },
]