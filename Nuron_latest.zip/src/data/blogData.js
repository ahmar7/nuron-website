import {
    Blog_1
} from "../utils/allImgs";

export const blogData = [
    {
        title: 'The services provide for design',
        detail: 'Development',
        time: '2 hour read',
        img: Blog_1,

    },
    {
        title: 'More important feature for designer',
        detail: 'Design',
        time: '5 min read',
        img: Blog_1,

    },
    {
        title: 'Inavalide purpose classes &amp; motivation.',
        detail: 'Marketing',
        time: '10 min read',
        img: Blog_1,

    },
    {
        title: "Canada is a great fact for NFT's",
        detail: "NFT's",
        time: '1 min read',
        img: Blog_1,
    },
]