export const blogData = [
    {
        title: 'The services provide for design',
        detail: 'Development',
        time: '2 hour read',
        img: Blog_1,

    },
    {
        title: 'More important feature for designer',
        detail: 'Design',
        time: '5 min read',
        img: Blog_1,

    },
]