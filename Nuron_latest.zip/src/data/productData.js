

import { Portfolio } from "../utils/allImgs"
//////////////////////////////////// Main-product
export const productData = [
    // {
    //     title: 'Video',
    //     quantity: '15 Items',
    //     lgimg: Collection_lg_1,
    //     smimg: Collection_sm_1,
    //     clientimg: Client_15,
    //     collectionTasks: [
    //         {
    //             img: Portfolio,
    //             name: 'Preatent',
    //             bid: 'Highest bid 1/20',
    //         },
    //         {
    //             img: Portfolio,
    //             name: 'Diamond Dog',
    //             bid: 'Highest bid 5/11'
    //         }
    //     ]
    // },


    {
        img: Portfolio,
        name: 'Preatent',
        bid: 'Highest bid 1/20',

    },

    {
        img: Portfolio,
        name: 'Diamond Dog',
        bid: 'Highest bid 5/11',

    },
    {
        img: Portfolio,
        name: 'OrBid6',
        bid: 'Highest bid 2/31',

    },
    {
        img: Portfolio,
        name: 'Morgan11',
        bid: 'Highest bid 3/16',

    },
    {
        img: Portfolio,
        name: 'mAtal8',
        bid: 'Highest bid 6/50',

    },
    {
        img: Portfolio,
        name: 'Platonum',
        bid: 'Highest bid 1/10',

    },
    {
        img: Portfolio,
        name: 'Orgajis',
        bid: 'Highest bid 2/10',

    },
    {
        img: Portfolio,
        name: '#720',
        bid: 'Highest bid 1/1',

    },
    {
        img: Portfolio,
        name: 'Orthogon#720',
        bid: 'Highest bid 1/1',

    }
]
///////////////////////////////////////// Category-1
export const productData1 = [
    {
        img: Portfolio,
        name: 'Preatent',
        bid: 'Highest bid 1/20',

    },
    {
        img: Portfolio,
        name: 'Preatent',
        bid: 'Highest bid 1/20',

    }
]
///////////////////////////////////////// Category-2
export const productData2 = [
    {
        img: Portfolio,
        name: 'Diamond Dog',
        bid: 'Highest bid 5/11',

    },
    {
        img: Portfolio,
        name: 'Diamond Dog',
        bid: 'Highest bid 5/11',

    }
]
///////////////////////////////////////// Category-3
export const productData3 = [

    {
        img: Portfolio,
        name: 'Orgajis',
        bid: 'Highest bid 2/10',

    },
    {
        img: Portfolio,
        name: 'Orgajis',
        bid: 'Highest bid 2/10',

    },
]
///////////////////////////////////////// Category-4
export const productData4 = [
    {
        img: Portfolio,
        name: 'Morgan11',
        bid: 'Highest bid 3/16',

    },
    {
        img: Portfolio,
        name: 'mAtal8',
        bid: 'Highest bid 6/50',

    },
    {
        img: Portfolio,
        name: 'Platonum',
        bid: 'Highest bid 1/10',

    },
    {
        img: Portfolio,
        name: 'PlatOrgan',
        bid: 'Highest bid 2/22',

    },

]