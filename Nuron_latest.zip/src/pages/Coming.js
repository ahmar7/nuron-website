import React from 'react';
import Comingsoon from '../components/ComingSoon/coming'
const Coming = () => {
    return (
        <div>
            <Comingsoon />
        </div>
    );
}

export default Coming;
