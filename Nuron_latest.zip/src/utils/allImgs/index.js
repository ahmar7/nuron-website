import Blog_1 from "../../assets/images/blog/blog-02.jpg";
import Collection_lg_1 from "../../assets/images/collection/collection-lg-01.jpg";
import Collection_sm_1 from "../../assets/images/collection/collection-sm-01.jpg";
import Client_15 from "../../assets/images/client/client-15.png";
import Client_1 from "../../assets/images/client/client-1.png";
import Client_2 from "../../assets/images/client/client-2.png";
import Portfolio from "../../assets/images/portfolio/portfolio-01.jpg";
import Shape_07 from "../../assets/images/icons/shape-7.png";
import Shape_01 from "../../assets/images/icons/shape-1.png";

import Shape_5 from "../../assets/images/icons/shape-5.png";
import Shape_06 from "../../assets/images/icons/shape-6.png";
///////////////////////////////////////////////////// Collection Images
export {
    Collection_lg_1,
    Collection_sm_1,
    Client_15,

}
///////////////////////////////////////////////////// Product Images
export {
    Portfolio
}

///////////////////////////////////////////////////// Service Images


export {
    Shape_01,
    Shape_5,
    Shape_06,
    Shape_07,

}
/////////////////////////////////////////////////////Blog Images

export {
    Blog_1

}

////////////////////////////////////////////////////// Creater images
export {
    Client_1

}
////////////////////////////////////////////////////// Creater images
export {
    Client_2

}